# RaceDay_poe_part2
# RaceDay

![CI/CD](https://github.com/ST1047510/RaceDayPoe_Part2/actions/workflows/ci-cd.yml/badge.svg)

RaceDay is a web API for organising race events. Organizers create categories and events, participants join events and enrol with a bib number, and organizers record the results after the race.

## Features

- **Accounts:** register and log in as an Organizer or a Participant. Passwords are hashed with BCrypt.
- **Categories:** organizers create age-based categories (minimum and maximum age) for their events.
- **Events:** organizers create, update and delete their own events. Each event has a name, description, date, location, maximum participants and status.
- **Joining:** participants join an event. Joining the same event twice is refused.
- **Enrollment:** a participant who has joined an event enrols with a bib number and a status.
- **Results:** organizers record the finish time, position and status for each enrolled participant.

## Business rules

| Area | Rule |
| --- | --- |
| Registration | Emails must be unique. Registering as an Organizer also creates an organizer record. |
| Passwords | At least 8 characters, no spaces, and must include an uppercase letter, a lowercase letter, a number and a special character. |
| Events | Only Organizers can create events. Only the organizer who owns an event can update or delete it. Deleting an event also removes its participants. |
| Categories | Only Organizers can create categories. A category that is used by an event cannot be deleted. |
| Joining | Only registered Participants can join an event, and only once. |
| Enrollment | A participant must join an event before enrolling in it. |
| Results | Only Organizers can create results, and the bib number must belong to an enrollment in that event. |

## Tech stack

- C# / ASP.NET Core Web API
- SQL Server (LocalDB for development)
- BCrypt.Net for password hashing
- xUnit for tests
- GitHub Actions for CI/CD

## Project structure

```
RaceDay/
├── .github/workflows/ci-cd.yml     CI/CD pipeline
├── database/schema.sql             database tables (used by the pipeline)
├── RaceDay_poe_part2/              the API
│   ├── backend/                    business logic and database access
│   └── Controllers/                API controllers (Auth, Events, Categories, Enrollments)
└── Raceday_tests2/                 xUnit tests
```

> Update this tree if your folders are named differently.

## Database

The API uses a SQL Server database called `racedaydb` with these tables:

| Table | Purpose |
| --- | --- |
| `users` | every account, with its role |
| `Organizers` | one row per organizer, linked to a user |
| `Catergories` | race categories, linked to an organizer |
| `Events` | races, linked to an organizer and a category |
| `Participants` | a user who joined an event |
| `Enrollment` | a participant's bib number and status for an event |
| `Results` | finish time, position and status for an enrollment |

## Getting started

### Prerequisites

- [.NET SDK](https://dotnet.microsoft.com/download) (the version in the project's `.csproj`)
- SQL Server LocalDB (installed with Visual Studio's "Data storage and processing" workload) or SQL Server Express
- Visual Studio 2022 or newer, or the `dotnet` CLI

### Set up

1. Clone the repository:

   ```bash
   git clone https://github.com/YOUR-USERNAME/YOUR-REPO.git
   cd YOUR-REPO
   ```

2. Create the LocalDB instance and the database:

   ```bash
   sqllocaldb create raceday_api
   sqllocaldb start raceday_api
   sqlcmd -S "(localdb)\raceday_api" -E -Q "CREATE DATABASE racedaydb"
   sqlcmd -S "(localdb)\raceday_api" -E -d racedaydb -i database/schema.sql
   ```

3. Check the connection string. The project expects:

   ```
   Data source=(localdb)\raceday_api;database=racedaydb;Integrated Security=true;TrustServerCertificate=true;
   ```

4. Run the API:

   ```bash
   dotnet run --project RaceDay_poe_part2
   ```

## API overview

> Fill this in with your real routes.

| Controller | What it does |
| --- | --- |
| `AuthController` | register and log in |
| `EventsController` | create, view, update, delete and join events |
| `CategoriesController` | create, update and delete categories |
| `EnrollmentsController` | create, view, update and delete enrollments |
| Results | create, view, update and delete results |

## Running the tests

```bash
dotnet test
```

The tests run against the real `racedaydb` database. Every test seeds its own data and cleans up before and after, and the cleanup only deletes rows whose names start with `XUNIT_` or whose emails look like `xunit_...@raceday.test`. Do not give your own data those names.

The tests are written in this style: one comment block per test, an object for the class under test, `test_results` and `expected_results` variables, then an assert.

## CI/CD

The workflow in `.github/workflows/ci-cd.yml` runs on every push and pull request to `main`:

1. **Build and test:** builds the solution, creates a LocalDB database from `database/schema.sql`, and runs the xUnit tests.
2. **Publish:** on pushes to `main`, publishes the API and stores it as a build artifact.
3. **Deploy:** if the repository variable `AZURE_WEBAPP_NAME` and the secret `AZURE_WEBAPP_PUBLISH_PROFILE` are set, deploys to Azure App Service.

## Author

[Your name] – [Your student number / contact]

## Licence

[Choose a licence, for example MIT, or remove this section.]
